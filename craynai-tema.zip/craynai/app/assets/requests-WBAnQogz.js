import{a as e,r as t}from"./paths-BOD3SrL7.js";import{t as n}from"./react-Db9NRdjC.js";import{c as r}from"./site-COkvJxYp.js";var i=e(n(),1),a=t(),o=.5,s=.35,c=30,l=2,u=84,d=`#version 300 es
const vec2 P[3] = vec2[3](vec2(-1.0, -1.0), vec2(3.0, -1.0), vec2(-1.0, 3.0));
void main() { gl_Position = vec4(P[gl_VertexID], 0.0, 1.0); }
`,f=`#version 300 es
precision highp float;
uniform vec2 uRes;
uniform float uTime;
uniform vec3 uC1;
uniform vec3 uC2;
uniform vec3 uBg;
uniform float uGain;
uniform vec2 uMouse;
uniform float uOn;
uniform float uReach;
uniform vec2 uVel;
out vec4 o;

const float LAYERS = ${u.toFixed(1)};
const float TWIST = 1.25;
const float DRAG = 0.18;
const float ANGLE = -3.14159265;
const vec2 CENTRE = vec2(-0.62, 0.24);
const float THETA = 2.13;

mat2 rot(float a) { float c = cos(a), s = sin(a); return mat2(c, s, -s, c); }
float dither(vec2 p, float f) { p += 5.588238 * mod(f, 64.0); return fract(52.9829189 * fract(0.06711056 * p.x + 0.00583715 * p.y)); }

void main() {
  vec2 pos = (gl_FragCoord.xy - 0.5 * uRes) / uRes.y;

  vec2 d = pos - uMouse;
  float w = uOn * exp(-dot(d, d) / (uReach * uReach));
  if (w > 1e-4) pos = uMouse + rot(w * TWIST) * d * (1.0 - 0.3 * min(w, 1.0)) - uVel * min(w, 1.0) * DRAG;

  pos = rot(ANGLE) * pos;
  float t = uTime * 0.49 + 12.0;
  float breath = (-sin(uTime * 0.735) + sin(uTime * 0.49 + 1.0)) * 0.25 + 0.5;
  vec2 u = rot(0.6) * ((pos - CENTRE) * (1.05 - breath * 0.085));
  mat2 fold = mat2(cos(THETA), sin(THETA), -0.963, cos(THETA));

  vec3 light = vec3(0.0);
  for (float i = 1.0; i <= LAYERS; i += 1.0) {
    u.x -= sin(u.y * 0.42 + t + i * 0.007) * 0.13;
    u.y -= sin(u.x * 2.4 - t + i * 0.02) * 0.027;
    u = fold * u * 0.953;
    vec2 q = (u - vec2(0.36 + breath * 0.1, 0.0)) * vec2(2.1, 0.17);
    float glow = 0.0021 / (dot(q, q) + 0.0019) * (0.25 + breath * 0.4);
    float r = length(u);
    float k = sin(i * 0.16 + t * 1.2 + r * 2.0) * 0.5 + 0.5;
    light += glow * mix(uC1, uC2, k) * (0.62 + 0.5 * k) * exp2(-r * 0.37);
  }
  vec3 x = max(light * uGain, 0.0);
  light = (x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14);
  light = pow(clamp(light, 0.0, 1.0), vec3(0.85, 0.92, 0.98));

  float strength = clamp(max(light.r, max(light.g, light.b)), 0.0, 1.0);
  vec3 color = uBg * (1.0 - strength) + light * 0.96;
  color += (dither(gl_FragCoord.xy, floor(uTime * 24.0)) - 0.5) / 255.0;
  o = vec4(clamp(color, 0.0, 1.0), 1.0);
}
`,p=e=>[1,3,5].map(t=>parseInt(e.slice(t,t+2),16)/255);function m(e,t,n){let r=e.createShader(t);return e.shaderSource(r,n),e.compileShader(r),e.getShaderParameter(r,e.COMPILE_STATUS)?r:(console.error(`AuroraFlow shader:`,e.getShaderInfoLog(r)),null)}function h({background:e=`#f6f4ef`,color1:t=`#2fd3f2`,color2:n=`#7b61ff`,intensity:r=1,speed:u=1,pointerSpeed:h=1,stillOnPhones:g=!1,className:_=``}){let v=(0,i.useRef)(null),y=(0,i.useRef)(null);return(0,i.useEffect)(()=>{let i=v.current,a=y.current,_=a.getContext(`webgl2`,{antialias:!1,alpha:!1,depth:!1,stencil:!1});if(!_)return;let b=m(_,_.VERTEX_SHADER,d),x=m(_,_.FRAGMENT_SHADER,f);if(!b||!x)return;let S=_.createProgram();_.attachShader(S,b),_.attachShader(S,x),_.linkProgram(S),_.useProgram(S),_.bindVertexArray(_.createVertexArray());let C=e=>_.getUniformLocation(S,e),w={res:C(`uRes`),time:C(`uTime`),mouse:C(`uMouse`),on:C(`uOn`),reach:C(`uReach`),vel:C(`uVel`)};_.uniform3f(C(`uC1`),...p(t)),_.uniform3f(C(`uC2`),...p(n)),_.uniform3f(C(`uBg`),...p(e)),_.uniform1f(C(`uGain`),.62*r);let T=0,E=0,D=new ResizeObserver(()=>{j&&g&&T&&i.clientWidth===T||(T=i.clientWidth,E=i.clientHeight,T&&E&&H())}),O={x:0,y:0,inside:!1},k=e=>{let t=i.getBoundingClientRect();O.x=e.clientX-t.left,O.y=e.clientY-t.top,O.inside=e.clientX>=t.left&&e.clientX<=t.right&&e.clientY>=t.top&&e.clientY<=t.bottom};window.addEventListener(`pointermove`,k,{passive:!0});let A=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches,j=window.matchMedia(`(pointer: coarse)`).matches,M=A||j&&g,N=0,P=-1,F=0,I=0,L=0,R=0,z=0,B=0,V=e=>{if(!T||!E){N=0,P=-1;return}if(N=M?0:requestAnimationFrame(V),!M&&j&&P>=0&&e-P<c)return;let t=P<0?0:Math.min((e-P)/1e3,.05);P=e,F=(F+t*u)%3600;let n=Math.min(window.devicePixelRatio||1,l)*(j?s:o),r=Math.max(1,Math.round(T*n)),i=Math.max(1,Math.round(E*n));(a.width!==r||a.height!==i)&&(a.width=r,a.height=i,_.viewport(0,0,r,i));let d=O.inside&&!A?1:0;d&&B<.02&&(I=O.x,L=O.y),B+=(d-B)*(1-Math.exp(-t*5*h));let f=1-Math.exp(-t*16*h),p=I+(O.x-I)*f,m=L+(O.y-L)*f;if(t>0){let e=1-Math.exp(-t*8*h);R+=((p-I)/t-R)*e,z+=((m-L)/t-z)*e}I=p,L=m;let g=Math.hypot(R,z)/E,v=g>3?3/g:1;_.uniform2f(w.res,r,i),_.uniform1f(w.time,F),_.uniform2f(w.mouse,(I-T/2)/E,(E/2-L)/E),_.uniform1f(w.on,B),_.uniform1f(w.reach,240/E),_.uniform2f(w.vel,R/E*v,-z/E*v),_.drawArrays(_.TRIANGLES,0,3)};function H(){N||=requestAnimationFrame(V)}return D.observe(i),()=>{cancelAnimationFrame(N),D.disconnect(),window.removeEventListener(`pointermove`,k),_.deleteProgram(S),_.deleteShader(b),_.deleteShader(x)}},[e,t,n,r,u,h,g]),(0,a.jsx)(`div`,{ref:v,"aria-hidden":`true`,className:`absolute inset-0 overflow-hidden ${_}`,style:{background:e},children:(0,a.jsx)(`canvas`,{ref:y,className:`block h-full w-full`})})}var g=window.CRAYN??{},_=Date.now(),v=`Bir hata oluştu ve talebiniz bize ulaşmadı. Lütfen biraz sonra tekrar deneyin ya da ${r.email} adresine yazın.`;async function y(e,t){if(!g.form)return;let n=new FormData;n.append(`action`,`crayn_talep`),n.append(`kaynak`,e),n.append(`sayfa`,window.location.href),n.append(`sure`,String(Math.round((Date.now()-_)/1e3)));for(let[e,r]of Object.entries(t))n.append(`alan[${e}]`,r);let r=await fetch(g.form,{method:`POST`,body:n}),i=await r.json().catch(()=>null);if(!r.ok||!i?.success)throw Error(`request not accepted`)}export{y as n,h as r,v as t};